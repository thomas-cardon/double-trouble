var searchData=
[
  ['item',['Item',['../structns_game_1_1_item.html',1,'nsGame']]]
];
