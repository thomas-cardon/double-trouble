var searchData=
[
  ['cell_5fsize',['CELL_SIZE',['../definitions_8h.html#a7a4127f14f16563da90eb3c836bc404f',1,'definitions.h']]],
  ['cooldowns_5fitem_5fspawn',['COOLDOWNS_ITEM_SPAWN',['../definitions_8h.html#a1527060528460e9daf2e62bfa08e9960',1,'definitions.h']]]
];
