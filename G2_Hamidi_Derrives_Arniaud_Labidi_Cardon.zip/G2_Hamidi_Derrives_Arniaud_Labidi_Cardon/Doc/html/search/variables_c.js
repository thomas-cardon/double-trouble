var searchData=
[
  ['n',['N',['../classns_game_1_1_player.html#a6fc5b1fa9ec5ca495fedf4908942d2f0',1,'nsGame::Player']]],
  ['numbers',['numbers',['../classns_game_1_1_game_state.html#a0b870e02f74c266d4a03dbe9210f7678',1,'nsGame::GameState']]]
];
