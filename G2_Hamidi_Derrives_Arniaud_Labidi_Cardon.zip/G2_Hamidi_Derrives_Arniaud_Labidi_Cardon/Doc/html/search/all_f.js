var searchData=
[
  ['params',['Params',['../classns_game_1_1_game_state.html#a972d8482f9ed69d536ff8c7927a8c290',1,'nsGame::GameState']]],
  ['params_2ecpp',['params.cpp',['../params_8cpp.html',1,'']]],
  ['params_2eh',['params.h',['../params_8h.html',1,'']]],
  ['player',['Player',['../classns_game_1_1_player.html',1,'nsGame::Player'],['../classns_game_1_1_player.html#a3b9991c6a7a1f910ab53a4e9fd1eb1f9',1,'nsGame::Player::Player()']]],
  ['player_2ecpp',['player.cpp',['../player_8cpp.html',1,'']]],
  ['player_2eh',['player.h',['../player_8h.html',1,'']]],
  ['player1',['player1',['../classns_game_1_1_game_state.html#aec14e8ba226edc828deabb6e6b276c70',1,'nsGame::GameState']]],
  ['player2',['player2',['../classns_game_1_1_game_state.html#abd99551650ebb05056576dd2fee40b4b',1,'nsGame::GameState']]],
  ['pos',['pos',['../structns_game_1_1_entity.html#a1ad359bb31e86c4971fd96b080ed43c4',1,'nsGame::Entity::pos()'],['../structns_game_1_1_item.html#a5518876a13f3d2eda659d29748097f1a',1,'nsGame::Item::pos()']]],
  ['power',['POWER',['../namespacens_game.html#afea521dd2ba8e97be9549ce9936f4522a3fb98417363f58fdca3c1736cb2bc524',1,'nsGame']]],
  ['powerup',['Powerup',['../classns_game_1_1_powerup.html',1,'nsGame::Powerup'],['../classns_game_1_1_powerup.html#a63e512471f199b9a4830785398f09378',1,'nsGame::Powerup::Powerup()'],['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7a8f64a06aec54275dc5b48f16ed3434d2',1,'nsGame::POWERUP()']]],
  ['powerup_2ecpp',['powerup.cpp',['../powerup_8cpp.html',1,'']]],
  ['powerup_2eh',['powerup.h',['../powerup_8h.html',1,'']]]
];
