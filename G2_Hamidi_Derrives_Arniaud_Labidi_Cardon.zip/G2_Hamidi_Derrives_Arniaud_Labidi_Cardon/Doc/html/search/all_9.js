var searchData=
[
  ['id',['id',['../structns_game_1_1_entity.html#aa0057e4e5b73cc0187602c3180347a3a',1,'nsGame::Entity::id()'],['../classns_game_1_1_monster.html#a14a0c542fe9c8b6772a3984ed674c9cf',1,'nsGame::Monster::id()'],['../classns_game_1_1_player.html#a339da658eb7a76de90ac66ec5cde929b',1,'nsGame::Player::id()']]],
  ['img2si',['img2si',['../namespaceimg2si.html',1,'']]],
  ['img2si_2epy',['img2si.py',['../entities_2monsters_24_m_2img2si_8py.html',1,'(Global Namespace)'],['../img2si_8py.html',1,'(Global Namespace)']]],
  ['incollision',['inCollision',['../structns_game_1_1_entity.html#a5dd00624fa76be09de80a6d2a982ea09',1,'nsGame::Entity']]],
  ['initgrid',['InitGrid',['../gridmanagement_8cpp.html#a7825f3ce7c418a5cc99213648f5badb3',1,'InitGrid(CMat &amp;Mat, const CMyParam &amp;Params, CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;gridmanagement.cpp'],['../gridmanagement_8h.html#a7825f3ce7c418a5cc99213648f5badb3',1,'InitGrid(CMat &amp;Mat, const CMyParam &amp;Params, CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;gridmanagement.cpp']]],
  ['initparams',['InitParams',['../params_8cpp.html#aa098c067e99e5d0c4b5671d86b96b2d2',1,'InitParams(CMyParam &amp;Param):&#160;params.cpp'],['../params_8h.html#aa098c067e99e5d0c4b5671d86b96b2d2',1,'InitParams(CMyParam &amp;Param):&#160;params.cpp']]],
  ['invincible',['INVINCIBLE',['../namespacens_game.html#afea521dd2ba8e97be9549ce9936f4522ad8419bc5aa898e494274288a9ac80024',1,'nsGame']]],
  ['is_5ffacing',['IS_FACING',['../classns_game_1_1_player.html#ae2def499a090256dbcc508d9b660cdce',1,'nsGame::Player']]],
  ['is_5ffile_5fsi2',['is_file_si2',['../namespaceimg2si.html#a30df945259118023030181e530c9f6df',1,'img2si']]],
  ['isallowedtomove',['isAllowedToMove',['../structns_game_1_1_entity.html#a3b26c2bf34732b4621932ab7d50421e9',1,'nsGame::Entity']]],
  ['iscooldownover',['isCooldownOver',['../classns_game_1_1_cooldowns.html#a423a58fcbbf7688556c5706249365f12',1,'nsGame::Cooldowns::isCooldownOver(std::string id)'],['../classns_game_1_1_cooldowns.html#ace34dc5863d0cf6aa01120832b382cd2',1,'nsGame::Cooldowns::isCooldownOver(std::string id, bool hasToDelete)']]],
  ['item',['Item',['../structns_game_1_1_item.html',1,'nsGame::Item'],['../structns_game_1_1_item.html#a7b70bf14fdd5c660ac1181f86482685b',1,'nsGame::Item::Item()'],['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7af9fff3d8a5eecce5e7a5832384af32c7',1,'nsGame::ITEM()']]],
  ['item_2eh',['item.h',['../item_8h.html',1,'']]],
  ['items',['items',['../classns_game_1_1_map.html#a8f7fa9511b608d41345adf1f3e3d1b29',1,'nsGame::Map']]],
  ['itemsleft',['itemsLeft',['../classns_game_1_1_map.html#addc6c2a156c156ee05b389fa9f500a20',1,'nsGame::Map']]],
  ['itemtype',['ItemType',['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7',1,'nsGame']]]
];
