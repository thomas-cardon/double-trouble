var searchData=
[
  ['food',['FOOD',['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7a4854f9b87edf18fbc6f4e3b5203e82fe',1,'nsGame']]],
  ['fruit',['FRUIT',['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7a11fef96488a5f7c7890a7e4a55c44ec9',1,'nsGame']]]
];
