var searchData=
[
  ['id',['id',['../structns_game_1_1_entity.html#aa0057e4e5b73cc0187602c3180347a3a',1,'nsGame::Entity::id()'],['../classns_game_1_1_monster.html#a14a0c542fe9c8b6772a3984ed674c9cf',1,'nsGame::Monster::id()'],['../classns_game_1_1_player.html#a339da658eb7a76de90ac66ec5cde929b',1,'nsGame::Player::id()']]],
  ['incollision',['inCollision',['../structns_game_1_1_entity.html#a5dd00624fa76be09de80a6d2a982ea09',1,'nsGame::Entity']]],
  ['initgrid',['InitGrid',['../gridmanagement_8cpp.html#a7825f3ce7c418a5cc99213648f5badb3',1,'InitGrid(CMat &amp;Mat, const CMyParam &amp;Params, CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;gridmanagement.cpp'],['../gridmanagement_8h.html#a7825f3ce7c418a5cc99213648f5badb3',1,'InitGrid(CMat &amp;Mat, const CMyParam &amp;Params, CPosition &amp;PosPlayer1, CPosition &amp;PosPlayer2):&#160;gridmanagement.cpp']]],
  ['initparams',['InitParams',['../params_8cpp.html#aa098c067e99e5d0c4b5671d86b96b2d2',1,'InitParams(CMyParam &amp;Param):&#160;params.cpp'],['../params_8h.html#aa098c067e99e5d0c4b5671d86b96b2d2',1,'InitParams(CMyParam &amp;Param):&#160;params.cpp']]],
  ['is_5ffile_5fsi2',['is_file_si2',['../namespaceimg2si.html#a30df945259118023030181e530c9f6df',1,'img2si']]],
  ['iscooldownover',['isCooldownOver',['../classns_game_1_1_cooldowns.html#a423a58fcbbf7688556c5706249365f12',1,'nsGame::Cooldowns::isCooldownOver(std::string id)'],['../classns_game_1_1_cooldowns.html#ace34dc5863d0cf6aa01120832b382cd2',1,'nsGame::Cooldowns::isCooldownOver(std::string id, bool hasToDelete)']]],
  ['item',['Item',['../structns_game_1_1_item.html#a7b70bf14fdd5c660ac1181f86482685b',1,'nsGame::Item']]]
];
