var searchData=
[
  ['window_5fheight',['WINDOW_HEIGHT',['../definitions_8h.html#a5473cf64fa979b48335079c99532e243',1,'definitions.h']]],
  ['window_5fwidth',['WINDOW_WIDTH',['../definitions_8h.html#a498d9f026138406895e9a34b504ac6a6',1,'definitions.h']]]
];
