var searchData=
[
  ['setcooldowndelay',['setCooldownDelay',['../classns_game_1_1_cooldowns.html#a0db5b81efac93aacc0b12b2aa520620b',1,'nsGame::Cooldowns']]],
  ['setcoordinates',['setCoordinates',['../classns_game_1_1_animation.html#a626733cd1a3031caf438b656f1d805cd',1,'nsGame::Animation']]],
  ['setmovementspeed',['setMovementSpeed',['../structns_game_1_1_entity.html#a0254c30b6223caa723303266ad04e4cd',1,'nsGame::Entity']]],
  ['setposition',['setPosition',['../classns_game_1_1_animation.html#a1a103b09407581b74933001fb8b3a8f0',1,'nsGame::Animation::setPosition(int x, int y)'],['../classns_game_1_1_animation.html#a2dc40787df4708e3f5d81e5529595574',1,'nsGame::Animation::setPosition(nsGraphics::Vec2D pos)']]],
  ['setstate',['setState',['../structns_game_1_1_state.html#adab442cc7a1edda5adaa55e8d510633f',1,'nsGame::State']]],
  ['spawn',['spawn',['../structns_game_1_1_entity.html#ac09f45ca50c9fef57a50c4414fc7e20d',1,'nsGame::Entity::spawn()'],['../classns_game_1_1_monster.html#a6ee4a9d2cea5d327379de3416a059169',1,'nsGame::Monster::spawn()'],['../classns_game_1_1_player.html#acab2fb26d3c0dddadccf7fcfc17b6e79',1,'nsGame::Player::spawn()']]],
  ['spawnitem',['spawnItem',['../classns_game_1_1_map.html#a7197e3e471d8a827ad195e74707f4052',1,'nsGame::Map']]]
];
