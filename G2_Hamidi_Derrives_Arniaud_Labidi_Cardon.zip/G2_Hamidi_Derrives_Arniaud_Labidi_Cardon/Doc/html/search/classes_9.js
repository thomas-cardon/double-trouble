var searchData=
[
  ['state',['State',['../structns_game_1_1_state.html',1,'nsGame']]],
  ['statemanager',['StateManager',['../classns_game_1_1_state_manager.html',1,'nsGame']]]
];
