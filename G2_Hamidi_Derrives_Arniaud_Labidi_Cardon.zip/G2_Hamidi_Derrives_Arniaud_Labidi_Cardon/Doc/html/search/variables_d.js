var searchData=
[
  ['params',['Params',['../classns_game_1_1_game_state.html#a972d8482f9ed69d536ff8c7927a8c290',1,'nsGame::GameState']]],
  ['player1',['player1',['../classns_game_1_1_game_state.html#aec14e8ba226edc828deabb6e6b276c70',1,'nsGame::GameState']]],
  ['player2',['player2',['../classns_game_1_1_game_state.html#abd99551650ebb05056576dd2fee40b4b',1,'nsGame::GameState']]],
  ['pos',['pos',['../structns_game_1_1_entity.html#a1ad359bb31e86c4971fd96b080ed43c4',1,'nsGame::Entity::pos()'],['../structns_game_1_1_item.html#a5518876a13f3d2eda659d29748097f1a',1,'nsGame::Item::pos()']]]
];
