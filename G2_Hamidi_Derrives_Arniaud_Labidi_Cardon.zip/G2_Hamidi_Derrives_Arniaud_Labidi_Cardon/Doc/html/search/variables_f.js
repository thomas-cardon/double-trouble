var searchData=
[
  ['score',['score',['../classns_game_1_1_player.html#af284db40fc7f885cc5ad889124e182c0',1,'nsGame::Player']]],
  ['sidebar',['sidebar',['../classns_game_1_1_game_state.html#a144f7f71a2a43f8422a346e4bc9bb923',1,'nsGame::GameState']]],
  ['slain',['slain',['../structns_game_1_1_entity.html#aaf71fbc10979dcc5b5af55fcb6e44216',1,'nsGame::Entity']]],
  ['sprite',['sprite',['../class_credit_state.html#a10ae436f8c1ca5d87cc960ada3cadb18',1,'CreditState']]],
  ['sprites',['sprites',['../classns_game_1_1_animation.html#a1757a8a9ce0a3fc6a75b1289b78753bb',1,'nsGame::Animation']]],
  ['statemanager',['stateManager',['../game2d_8cpp.html#a01a766e1fb950604f31bd22c2253c59b',1,'game2d.cpp']]]
];
