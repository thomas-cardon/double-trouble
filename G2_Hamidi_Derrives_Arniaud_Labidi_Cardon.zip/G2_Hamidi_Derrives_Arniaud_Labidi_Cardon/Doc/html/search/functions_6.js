var searchData=
[
  ['getcoordinates',['getCoordinates',['../classns_game_1_1_cookie.html#ab624101d018f74fb856bdfd7fd97c55e',1,'nsGame::Cookie::getCoordinates()'],['../structns_game_1_1_entity.html#a727ed96ea0a27b7232e701ed0ba6d3a4',1,'nsGame::Entity::getCoordinates()'],['../structns_game_1_1_item.html#a52af52633c8924e35b47347f8c51a22e',1,'nsGame::Item::getCoordinates()'],['../classns_game_1_1_powerup.html#a31700271cd7bd2040d26bcac7f437408',1,'nsGame::Powerup::getCoordinates()']]],
  ['getemptyposition',['getEmptyPosition',['../classns_game_1_1_map.html#a9c7ae85f01db94d0bedbce4aee4d52f0',1,'nsGame::Map']]],
  ['getemptypositions',['getEmptyPositions',['../classns_game_1_1_map.html#a098dda0872f84fa83c61693efaca48f1',1,'nsGame::Map']]],
  ['getheight',['getHeight',['../classns_game_1_1_map.html#a8ae7e6fe93f1318c0d7d2569e73ec144',1,'nsGame::Map']]],
  ['getmat',['getMat',['../classns_game_1_1_map.html#a2cbbebf0522026dff6cfbb0236fe5150',1,'nsGame::Map']]],
  ['getminx',['getMinX',['../classns_game_1_1_map.html#ad3a11fea3eca423e6a1784078b379f84',1,'nsGame::Map']]],
  ['getminy',['getMinY',['../classns_game_1_1_map.html#a07b09c358fb25b0dea037994e8867d09',1,'nsGame::Map']]],
  ['getmovementspeed',['getMovementSpeed',['../structns_game_1_1_entity.html#a03b934337b3c013abcccf3dfea6396d1',1,'nsGame::Entity']]],
  ['getposition',['getPosition',['../structns_game_1_1_entity.html#ab7fc1631346d2c643161d229dd653edd',1,'nsGame::Entity::getPosition()'],['../structns_game_1_1_item.html#abd124b5001b8dc63b8513e5b85c6c2b9',1,'nsGame::Item::getPosition()']]],
  ['getrandomlevel',['getRandomLevel',['../map_8cpp.html#a80ba96737f2daeda26fdd4bf7488cc26',1,'map.cpp']]],
  ['getstate',['getState',['../structns_game_1_1_state.html#abcc65369e15769b5c6ae588f61beeb02',1,'nsGame::State']]],
  ['gettype',['getType',['../classns_game_1_1_cookie.html#ac5c28f610947708bc1f31b1e8a88ef42',1,'nsGame::Cookie::getType()'],['../classns_game_1_1_fruit.html#a4d704f296f536afc2980183bb21e4c62',1,'nsGame::Fruit::getType()'],['../structns_game_1_1_item.html#a69156550e5083928cbb673ca2db671f5',1,'nsGame::Item::getType()'],['../classns_game_1_1_powerup.html#a34f105d75a90ddbbc6afa46c83bdccf6',1,'nsGame::Powerup::getType()']]],
  ['getwidth',['getWidth',['../classns_game_1_1_map.html#a948d05a71e53131418c9cf19c2da1062',1,'nsGame::Map']]]
];
