var searchData=
[
  ['effect',['Effect',['../type_8h.html#ad7b87ea1ccd7642b3a46c6a7de328b4b',1,'type.h']]]
];
