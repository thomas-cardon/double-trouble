var searchData=
[
  ['power',['POWER',['../namespacens_game.html#afea521dd2ba8e97be9549ce9936f4522a3fb98417363f58fdca3c1736cb2bc524',1,'nsGame']]],
  ['powerup',['POWERUP',['../namespacens_game.html#a5f7db01e6447720e9a145f0b3c68a4d7a8f64a06aec54275dc5b48f16ed3434d2',1,'nsGame']]]
];
