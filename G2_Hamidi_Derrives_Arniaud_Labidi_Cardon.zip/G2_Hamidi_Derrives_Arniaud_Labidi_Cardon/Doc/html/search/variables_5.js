var searchData=
[
  ['frames',['frames',['../game2d_8cpp.html#a61217d5bc9d5b446d9c08e7ca401b733',1,'game2d.cpp']]]
];
