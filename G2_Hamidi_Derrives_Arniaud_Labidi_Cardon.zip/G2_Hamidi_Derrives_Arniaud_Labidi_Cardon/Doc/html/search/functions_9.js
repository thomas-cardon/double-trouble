var searchData=
[
  ['kill',['kill',['../structns_game_1_1_entity.html#a522648b330daab91b49f78f0737a943f',1,'nsGame::Entity']]]
];
