var searchData=
[
  ['player',['Player',['../classns_game_1_1_player.html#a3b9991c6a7a1f910ab53a4e9fd1eb1f9',1,'nsGame::Player']]],
  ['powerup',['Powerup',['../classns_game_1_1_powerup.html#a63e512471f199b9a4830785398f09378',1,'nsGame::Powerup']]]
];
