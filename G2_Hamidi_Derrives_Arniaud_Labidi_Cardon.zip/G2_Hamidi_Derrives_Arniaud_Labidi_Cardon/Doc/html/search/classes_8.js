var searchData=
[
  ['player',['Player',['../classns_game_1_1_player.html',1,'nsGame']]],
  ['powerup',['Powerup',['../classns_game_1_1_powerup.html',1,'nsGame']]]
];
