var searchData=
[
  ['entity',['Entity',['../structns_game_1_1_entity.html',1,'nsGame']]]
];
