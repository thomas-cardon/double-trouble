var searchData=
[
  ['nsgame',['nsGame',['../namespacens_game.html',1,'']]]
];
