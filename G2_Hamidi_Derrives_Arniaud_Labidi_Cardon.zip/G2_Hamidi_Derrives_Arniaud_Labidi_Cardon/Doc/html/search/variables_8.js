var searchData=
[
  ['is_5ffacing',['IS_FACING',['../classns_game_1_1_player.html#ae2def499a090256dbcc508d9b660cdce',1,'nsGame::Player']]],
  ['isallowedtomove',['isAllowedToMove',['../structns_game_1_1_entity.html#a3b26c2bf34732b4621932ab7d50421e9',1,'nsGame::Entity']]],
  ['items',['items',['../classns_game_1_1_map.html#a8f7fa9511b608d41345adf1f3e3d1b29',1,'nsGame::Map']]],
  ['itemsleft',['itemsLeft',['../classns_game_1_1_map.html#addc6c2a156c156ee05b389fa9f500a20',1,'nsGame::Map']]]
];
