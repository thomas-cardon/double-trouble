var searchData=
[
  ['score',['score',['../classns_game_1_1_player.html#af284db40fc7f885cc5ad889124e182c0',1,'nsGame::Player']]],
  ['score_5ffood',['SCORE_FOOD',['../definitions_8h.html#a0cdfa5aa244e095501232b0bb313ac3b',1,'definitions.h']]],
  ['score_5ffruit',['SCORE_FRUIT',['../definitions_8h.html#aad089c17653b4d8367027538786f4280',1,'definitions.h']]],
  ['setcooldowndelay',['setCooldownDelay',['../classns_game_1_1_cooldowns.html#a0db5b81efac93aacc0b12b2aa520620b',1,'nsGame::Cooldowns']]],
  ['setcoordinates',['setCoordinates',['../classns_game_1_1_animation.html#a626733cd1a3031caf438b656f1d805cd',1,'nsGame::Animation']]],
  ['setmovementspeed',['setMovementSpeed',['../structns_game_1_1_entity.html#a0254c30b6223caa723303266ad04e4cd',1,'nsGame::Entity']]],
  ['setposition',['setPosition',['../classns_game_1_1_animation.html#a1a103b09407581b74933001fb8b3a8f0',1,'nsGame::Animation::setPosition(int x, int y)'],['../classns_game_1_1_animation.html#a2dc40787df4708e3f5d81e5529595574',1,'nsGame::Animation::setPosition(nsGraphics::Vec2D pos)']]],
  ['setstate',['setState',['../structns_game_1_1_state.html#adab442cc7a1edda5adaa55e8d510633f',1,'nsGame::State']]],
  ['sidebar',['sidebar',['../classns_game_1_1_game_state.html#a144f7f71a2a43f8422a346e4bc9bb923',1,'nsGame::GameState']]],
  ['slain',['slain',['../structns_game_1_1_entity.html#aaf71fbc10979dcc5b5af55fcb6e44216',1,'nsGame::Entity']]],
  ['spawn',['spawn',['../structns_game_1_1_entity.html#ac09f45ca50c9fef57a50c4414fc7e20d',1,'nsGame::Entity::spawn()'],['../classns_game_1_1_monster.html#a6ee4a9d2cea5d327379de3416a059169',1,'nsGame::Monster::spawn()'],['../classns_game_1_1_player.html#acab2fb26d3c0dddadccf7fcfc17b6e79',1,'nsGame::Player::spawn()']]],
  ['spawnitem',['spawnItem',['../classns_game_1_1_map.html#a7197e3e471d8a827ad195e74707f4052',1,'nsGame::Map']]],
  ['sprite',['sprite',['../class_credit_state.html#a10ae436f8c1ca5d87cc960ada3cadb18',1,'CreditState']]],
  ['sprites',['sprites',['../classns_game_1_1_animation.html#a1757a8a9ce0a3fc6a75b1289b78753bb',1,'nsGame::Animation']]],
  ['state',['State',['../structns_game_1_1_state.html',1,'nsGame']]],
  ['state_2eh',['state.h',['../state_8h.html',1,'']]],
  ['statemanager',['StateManager',['../classns_game_1_1_state_manager.html',1,'nsGame::StateManager'],['../game2d_8cpp.html#a01a766e1fb950604f31bd22c2253c59b',1,'stateManager():&#160;game2d.cpp']]],
  ['statemanager_2ecpp',['stateManager.cpp',['../state_manager_8cpp.html',1,'']]],
  ['statemanager_2eh',['stateManager.h',['../state_manager_8h.html',1,'']]]
];
