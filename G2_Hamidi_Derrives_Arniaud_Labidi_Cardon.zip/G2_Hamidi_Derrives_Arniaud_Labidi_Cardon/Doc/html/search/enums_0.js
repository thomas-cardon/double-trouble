var searchData=
[
  ['effecttype',['EffectType',['../namespacens_game.html#afea521dd2ba8e97be9549ce9936f4522',1,'nsGame']]]
];
