var searchData=
[
  ['menu_5fkey',['MENU_KEY',['../definitions_8h.html#aac3810c1848202b2e9a19348b77c6dee',1,'definitions.h']]]
];
