var searchData=
[
  ['gamestate',['GameState',['../classns_game_1_1_game_state.html',1,'nsGame']]]
];
