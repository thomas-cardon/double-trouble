var searchData=
[
  ['win',['win',['../classns_game_1_1_game_state.html#aa5b4cb6af0e806d442e5291578a6822a',1,'nsGame::GameState']]],
  ['window_5fheight',['WINDOW_HEIGHT',['../definitions_8h.html#a5473cf64fa979b48335079c99532e243',1,'definitions.h']]],
  ['window_5fwidth',['WINDOW_WIDTH',['../definitions_8h.html#a498d9f026138406895e9a34b504ac6a6',1,'definitions.h']]]
];
