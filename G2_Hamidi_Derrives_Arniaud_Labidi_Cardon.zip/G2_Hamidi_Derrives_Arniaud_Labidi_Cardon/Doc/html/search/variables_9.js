var searchData=
[
  ['kauthorizedkey',['KAuthorizedKey',['../type_8h.html#aeb6b858f886b8520a7f220b3de0bef1a',1,'type.h']]],
  ['key_5faction_5f1',['KEY_ACTION_1',['../classns_game_1_1_player.html#a803a385cf0a9bb45ba8c17fe66ae13d6',1,'nsGame::Player']]],
  ['key_5fdown',['KEY_DOWN',['../classns_game_1_1_player.html#a9c8418e477b2a3609195a0f4b9cceef8',1,'nsGame::Player']]],
  ['key_5fleft',['KEY_LEFT',['../classns_game_1_1_player.html#ac7234b6672244108f24a1a606f5b7967',1,'nsGame::Player']]],
  ['key_5fright',['KEY_RIGHT',['../classns_game_1_1_player.html#ae3e71092e1e40488562025cd8f6484ab',1,'nsGame::Player']]],
  ['key_5fup',['KEY_UP',['../classns_game_1_1_player.html#ad51e2d88b5eaab00bcfdf787bd13c437',1,'nsGame::Player']]]
];
