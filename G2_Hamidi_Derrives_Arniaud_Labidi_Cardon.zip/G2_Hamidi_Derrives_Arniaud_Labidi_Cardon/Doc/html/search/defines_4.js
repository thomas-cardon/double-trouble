var searchData=
[
  ['res_5fpath',['RES_PATH',['../definitions_8h.html#a793644bd88146828177a2a4f57e3bf01',1,'definitions.h']]]
];
