var searchData=
[
  ['right',['right',['../classns_game_1_1_monster.html#a32a00b717e96ccc6008b978d048802d6',1,'nsGame::Monster::right()'],['../classns_game_1_1_player.html#a90ec9f96623d92ed28938e3770c16936',1,'nsGame::Player::right()']]]
];
