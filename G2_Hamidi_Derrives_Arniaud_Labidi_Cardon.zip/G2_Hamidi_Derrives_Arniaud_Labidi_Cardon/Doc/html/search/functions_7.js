var searchData=
[
  ['haseffect',['hasEffect',['../structns_game_1_1_entity.html#af5bf634702f96ed5daac8130a3dee4f0',1,'nsGame::Entity']]]
];
