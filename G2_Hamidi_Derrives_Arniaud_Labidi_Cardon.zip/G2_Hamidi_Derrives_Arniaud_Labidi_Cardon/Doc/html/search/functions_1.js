var searchData=
[
  ['action',['action',['../classns_game_1_1_cookie.html#a2cd4ee8c83b99191643d6e9ef2267b1a',1,'nsGame::Cookie::action()'],['../classns_game_1_1_fruit.html#ad33836a67756dba7390b95c57898e91c',1,'nsGame::Fruit::action()'],['../structns_game_1_1_item.html#af74dffcf9bde4a4297749f4e1852395b',1,'nsGame::Item::action()'],['../classns_game_1_1_powerup.html#af307aba7b61132f2dc037d8ef62581f9',1,'nsGame::Powerup::action()']]],
  ['addeffect',['addEffect',['../structns_game_1_1_entity.html#a0fbe0a80400a03319fbe3bd50919535c',1,'nsGame::Entity']]],
  ['animation',['Animation',['../classns_game_1_1_animation.html#aebaabfa10569678e6a7d30fa9c8d031d',1,'nsGame::Animation::Animation()'],['../classns_game_1_1_animation.html#a0554455321614f3f94bbcbd5b784cfd5',1,'nsGame::Animation::Animation(nsGraphics::Vec2D pos)'],['../classns_game_1_1_animation.html#a022c8e1738aee4ce2e2c15abbeedc711',1,'nsGame::Animation::Animation(unsigned delay, bool alternate)'],['../classns_game_1_1_animation.html#a0170b0eeb1b1f41d4f0a5270877e9897',1,'nsGame::Animation::Animation(unsigned delay, bool alternate, nsGraphics::Vec2D pos)']]]
];
