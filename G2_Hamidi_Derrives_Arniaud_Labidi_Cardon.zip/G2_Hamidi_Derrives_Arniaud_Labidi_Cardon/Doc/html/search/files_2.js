var searchData=
[
  ['definitions_2eh',['definitions.h',['../definitions_8h.html',1,'']]]
];
