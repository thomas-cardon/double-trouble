var searchData=
[
  ['_5fgetdelay',['_getDelay',['../structns_game_1_1_entity.html#a0c574fba3e12b9bb976d72953626e550',1,'nsGame::Entity']]]
];
