var searchData=
[
  ['score_5ffood',['SCORE_FOOD',['../definitions_8h.html#a0cdfa5aa244e095501232b0bb313ac3b',1,'definitions.h']]],
  ['score_5ffruit',['SCORE_FRUIT',['../definitions_8h.html#aad089c17653b4d8367027538786f4280',1,'definitions.h']]]
];
